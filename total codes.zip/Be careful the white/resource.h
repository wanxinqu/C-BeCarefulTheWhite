//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ��Ȱ׿�.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_MY_FORM                     101
#define IDR_MAINFRAME                   128
#define IDR_MYTYPE                      129
#define IDB_yellow                      130
#define IDB_black                       131
#define IDB_grey                        133
#define IDB_start                       134
#define IDB_white                       135
#define IDB_green                       136
#define IDD_DIALOG_KEY                  137
#define IDB_jingdian                    138
#define IDB_jieji                       139
#define IDB_chan                        140
#define IDB_gengduo                     141
#define IDB_HuoJian                     142
#define IDB_WuGui                       143
#define IDD_ZHUTI                       146
#define IDB_blue                        147
#define IDB_start2                      148
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_BUTTON1                     1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON2                     1002
#define IDC_EDIT4                       1003
#define ID_RETRY                        32771
#define ID_EXIT                         32772
#define ID_SETKEY                       32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
