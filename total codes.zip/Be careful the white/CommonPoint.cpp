// CommonPoint.cpp: implementation of the CommonPoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "��Ȱ׿�.h"
#include "CommonPoint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CommonPoint::CommonPoint()
{

}

CommonPoint::~CommonPoint()
{

}


void CommonPoint::SetPoint()
{
	
}