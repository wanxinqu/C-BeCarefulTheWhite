// MyTime.h: interface for the MyTime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYTIME_H__A64D193E_12A1_4032_BA89_1DED6A550F82__INCLUDED_)
#define AFX_MYTIME_H__A64D193E_12A1_4032_BA89_1DED6A550F82__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MyTime  
{
public:
	
	MyTime();
	virtual ~MyTime();

};

#endif // !defined(AFX_MYTIME_H__A64D193E_12A1_4032_BA89_1DED6A550F82__INCLUDED_)
