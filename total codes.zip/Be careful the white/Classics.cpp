// Classics.cpp: implementation of the Classics class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "��Ȱ׿�.h"
#include "Classics.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Classics::Classics()
{
	
}

Classics::~Classics()
{

}


void Classics::CreatePoint4()
{

}
