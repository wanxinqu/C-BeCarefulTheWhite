// StreetModel.h: interface for the StreetModel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STREETMODEL_H__DD5FAEA4_BBE9_42C7_B88B_31BE87CCCCA6__INCLUDED_)
#define AFX_STREETMODEL_H__DD5FAEA4_BBE9_42C7_B88B_31BE87CCCCA6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AbstractFactory.h"

class StreetModel : public AbstractFactory  
{
public:
	StreetModel();
	virtual ~StreetModel();

	virtual void CreatePoint4();
	virtual void CreateSpecialEfficiency(){}

};

#endif // !defined(AFX_STREETMODEL_H__DD5FAEA4_BBE9_42C7_B88B_31BE87CCCCA6__INCLUDED_)
