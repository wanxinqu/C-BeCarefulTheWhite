// AbstractFactory.cpp: implementation of the AbstractFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "��Ȱ׿�.h"
#include "AbstractFactory.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

AbstractFactory::AbstractFactory()
{

}

AbstractFactory::~AbstractFactory()
{

}
