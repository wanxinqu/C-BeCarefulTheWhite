// CommonPoint.h: interface for the CommonPoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMMONPOINT_H__C9B369F2_0EE3_411A_B2E1_88AAC1A18E2C__INCLUDED_)
#define AFX_COMMONPOINT_H__C9B369F2_0EE3_411A_B2E1_88AAC1A18E2C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyPoint.h"

class CommonPoint : public MyPoint  
{
public:
	CommonPoint();
	virtual ~CommonPoint();

	virtual void SetPoint();

};

#endif // !defined(AFX_COMMONPOINT_H__C9B369F2_0EE3_411A_B2E1_88AAC1A18E2C__INCLUDED_)
