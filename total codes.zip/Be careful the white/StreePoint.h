// StreePoint.h: interface for the StreePoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STREEPOINT_H__2FF1CCD4_E917_49D8_897B_121F90696E3B__INCLUDED_)
#define AFX_STREEPOINT_H__2FF1CCD4_E917_49D8_897B_121F90696E3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyPoint.h"

class StreePoint : public MyPoint  
{
public:
	StreePoint();
	virtual ~StreePoint();

};

#endif // !defined(AFX_STREEPOINT_H__2FF1CCD4_E917_49D8_897B_121F90696E3B__INCLUDED_)
